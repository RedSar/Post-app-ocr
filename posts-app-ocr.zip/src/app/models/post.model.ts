export interface Post{
    title: string;
    content: string;
    lovIts: number;
    created_at: number;
}