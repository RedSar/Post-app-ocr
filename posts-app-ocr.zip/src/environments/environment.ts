

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBD5Fnz25EnP3zqBA48Nu_boy9OXKM7TBs",
    authDomain: "posts-ocr.firebaseapp.com",
    databaseURL: "https://posts-ocr.firebaseio.com",
    projectId: "posts-ocr",
    storageBucket: "posts-ocr.appspot.com",
    messagingSenderId: "175692773587",
    appId: "1:175692773587:web:465da8eb75442102a13c26"
  }
};

